# ECELL nitte — Frontend

React + Vite frontend for the NMAMIT Entrepreneurship Cell portal.

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Set environment variable
cp .env.example .env
# Edit .env and set VITE_API_URL to your backend URL

# 3. Run dev server
npm run dev
# Opens at http://localhost:3000
```

## What's built

### 4 Core Components

| Component | File | What it does |
|-----------|------|-------------|
| Events Page | `src/pages/public/Events.jsx` | Lists events, register button, event detail modal |
| Ticket Modal | `src/components/events/TicketModal.jsx` | Shows QR code image after registration |
| QR Scanner | `src/pages/admin/QrScanPage.jsx` | Camera scan → POST to API → show result |
| Admin Dashboard | `src/pages/admin/AdminDashboard.jsx` | Stats, events table, export Excel/CSV |

### API calls made

| Action | API Endpoint |
|--------|-------------|
| List events | `GET /events/` |
| Event detail | `GET /events/{slug}/` |
| Register for event | `POST /events/{slug}/register/` |
| Get my QR ticket | `GET /events/{slug}/my-registration/` |
| Scan QR (admin) | `POST /admin/events/{id}/scan/` |
| Export pre-event | `GET /admin/events/{id}/export/pre/` |
| Export attendance | `GET /admin/events/{id}/export/post/` |
| Dashboard stats | `GET /admin/dashboard/stats/` |

### Routes

| Route | Access | Page |
|-------|--------|------|
| `/events` | Public | Events listing |
| `/login` | Public | Login page |
| `/admin` | Admin only | Dashboard |
| `/admin/events` | Admin only | Events manager |
| `/admin/events/:id/scan` | Admin only | QR Scanner |

## Project structure

```
src/
├── api/
│   ├── axiosInstance.js    # Axios + JWT interceptor
│   └── services.js         # All API functions
├── store/
│   └── authStore.js        # Zustand auth state
├── pages/
│   ├── public/
│   │   └── Events.jsx      # Events listing + register
│   └── admin/
│       ├── AdminDashboard.jsx  # Dashboard + export
│       └── QrScanPage.jsx      # QR scanner
├── components/
│   └── events/
│       └── TicketModal.jsx # QR ticket display
├── styles/
│   └── app.css             # All styles
├── App.jsx                 # Router + layouts
└── main.jsx                # Entry point
```

## Adding to existing Flask/Django backend

The `VITE_API_URL` points to the Django backend.
All JWT tokens are stored in localStorage and injected automatically.
On 401, the token is refreshed silently.
