import api from './axiosInstance';

// ─── Auth ───
export const authApi = {
  login: (email, password) =>
    api.post('/auth/login/', { email, password }),
  register: (data) =>
    api.post('/auth/register/', data),
  me: () =>
    api.get('/auth/me/'),
  logout: (refresh) =>
    api.post('/auth/logout/', { refresh }),
};

// ─── Events ───
export const eventsApi = {
  list: (params) =>
    api.get('/events/', { params }),
  detail: (slug) =>
    api.get(`/events/${slug}/`),
  register: (slug) =>
    api.post(`/events/${slug}/register/`),
  myRegistration: (slug) =>
    api.get(`/events/${slug}/my-registration/`),
  myRegistrations: () =>
    api.get('/registrations/'),
};

// ─── Admin ───
export const adminApi = {
  // Events
  listEvents: (params) =>
    api.get('/admin/events/', { params }),
  createEvent: (data) =>
    api.post('/admin/events/', data),
  updateEvent: (id, data) =>
    api.patch(`/admin/events/${id}/`, data),
  deleteEvent: (id) =>
    api.delete(`/admin/events/${id}/`),

  // Registrations
  listRegistrations: (eventId) =>
    api.get(`/admin/events/${eventId}/registrations/`),

  // QR Scan
  scanQr: (eventId, token) =>
    api.post(`/admin/events/${eventId}/scan/`, { token }),

  // Export — returns file blob
  exportPre: (eventId) =>
    api.get(`/admin/events/${eventId}/export/pre/`, { responseType: 'blob' }),
  exportPost: (eventId) =>
    api.get(`/admin/events/${eventId}/export/post/`, { responseType: 'blob' }),

  // Dashboard
  stats: () =>
    api.get('/admin/dashboard/stats/'),

  // Team
  listTeam: () =>
    api.get('/admin/team/'),
};
