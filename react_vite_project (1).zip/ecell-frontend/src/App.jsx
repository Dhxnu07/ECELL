import { useState } from 'react';
import { createBrowserRouter, RouterProvider, Navigate, Outlet } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './store/authStore';
import './styles/app.css';

// Pages
import Events from './pages/public/Events';
import QrScanPage from './pages/admin/QrScanPage';
import { AdminDashboard, AdminEventsManager } from './pages/admin/AdminDashboard';
import BlogManager from './pages/admin/BlogManager';
import TeamManager from './pages/admin/TeamManager';
import { NotificationsPage, NotificationBell } from './components/admin/Notifications';

// Query client
const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

// ─── Route guards ───
function ProtectedRoute({ children }) {
  const { isAuthenticated } = useAuthStore();
  return isAuthenticated ? children : <Navigate to="/login" replace />;
}

function AdminRoute({ children }) {
  const { isAuthenticated, role } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (role !== 'admin') return <Navigate to="/" replace />;
  return children;
}

// ─── Layouts ───
function PublicLayout() {
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Outlet />
    </div>
  );
}

function AdminLayout() {
  const { logout } = useAuthStore();
  const path = window.location.pathname;

  const navItems = [
    { href: '/admin', label: 'Dashboard', icon: '⬡' },
    { href: '/admin/events', label: 'Events', icon: '📅' },
    { href: '/admin/startups', label: 'Startups', icon: '💡' },
    { href: '/admin/blog', label: 'Blog', icon: '✍️' },
    { href: '/admin/team', label: 'Team', icon: '👥' },
    { href: '/admin/notifications', label: 'Notifications', icon: '🔔' },
  ];

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="sidebar-logo" style={{justifyContent:'space-between'}}>
          <span>ECELL <span style={{color:'var(--gold)'}}>nitte</span></span>
          <NotificationBell />
        </div>
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={`nav-item ${path === item.href ? 'active' : ''}`}
            >
              <span className="nav-item-icon">{item.icon}</span>
              {item.label}
            </a>
          ))}
        </nav>
        <button
          onClick={() => { logout(); window.location.href = '/login'; }}
          className="nav-item"
          style={{ marginTop: 'auto', cursor: 'pointer', background: 'none', border: 'none', width: '100%', textAlign: 'left' }}
        >
          <span className="nav-item-icon">↩</span>
          Logout
        </button>
      </aside>
      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}

// ─── Router ───
const router = createBrowserRouter([
  {
    element: <PublicLayout />,
    children: [
      { path: '/', element: <Navigate to="/events" replace /> },
      { path: '/events', element: <Events /> },
    ],
  },
  {
    path: '/admin',
    element: <AdminRoute><AdminLayout /></AdminRoute>,
    children: [
      { index: true, element: <AdminDashboard /> },
      { path: 'events', element: <AdminEventsManager /> },
      { path: 'events/:id/scan', element: <QrScanPage /> },
      { path: 'blog', element: <BlogManager /> },
      { path: 'team', element: <TeamManager /> },
      { path: 'notifications', element: <NotificationsPage /> },
    ],
  },
  {
    path: '/login',
    element: <LoginPage />,
  },
]);

// ─── Login page (simple) ───
function LoginPage() {
  const { setAuth } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const { authApi } = await import('./api/services');
      const { data } = await authApi.login(email, password);
      const meRes = await import('./api/services').then(m => m.authApi.me());
      setAuth(meRes.data.data, data.data.access, data.data.refresh);
      window.location.href = meRes.data.data.role === 'admin' ? '/admin' : '/events';
    } catch (err) {
      setError(err.response?.data?.detail || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', padding: '20px' }}>
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '20px', padding: '40px', width: '100%', maxWidth: '400px' }}>
        <div style={{ textAlign: 'center', marginBottom: '28px' }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '24px', fontWeight: 800 }}>
            ECELL <span style={{ color: 'var(--gold)' }}>nitte</span>
          </div>
          <p style={{ color: 'var(--text-2)', marginTop: '6px', fontSize: '14px' }}>Sign in to your account</p>
        </div>
        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <input
            type="email" placeholder="Email address" value={email}
            onChange={(e) => setEmail(e.target.value)} required
            style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '12px 16px', color: 'var(--text-1)', fontSize: '14px', fontFamily: 'DM Sans, sans-serif' }}
          />
          <input
            type="password" placeholder="Password" value={password}
            onChange={(e) => setPassword(e.target.value)} required
            style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '12px 16px', color: 'var(--text-1)', fontSize: '14px', fontFamily: 'DM Sans, sans-serif' }}
          />
          {error && <p style={{ color: 'var(--error)', fontSize: '13px' }}>{error}</p>}
          <button
            type="submit" disabled={loading}
            style={{ background: 'var(--gold)', color: '#000', border: 'none', borderRadius: '10px', padding: '13px', fontSize: '15px', fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1, fontFamily: 'DM Sans, sans-serif' }}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1e1e1e',
            color: '#f0f0f0',
            border: '1px solid rgba(255,255,255,0.07)',
            borderRadius: '10px',
            fontSize: '14px',
          },
          success: { iconTheme: { primary: '#F5A623', secondary: '#000' } },
        }}
      />
    </QueryClientProvider>
  );
}
