import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '../../api/axiosInstance';
import toast from 'react-hot-toast';

// ─── API helpers ───
const blogApi = {
  listPosts:       (p) => api.get('/admin/blog/posts/', { params: p }),
  createPost:      (d) => api.post('/admin/blog/posts/', d, { headers: { 'Content-Type': 'multipart/form-data' } }),
  updatePost:      (id, d) => api.patch(`/admin/blog/posts/${id}/`, d, { headers: { 'Content-Type': 'multipart/form-data' } }),
  deletePost:      (id) => api.delete(`/admin/blog/posts/${id}/`),
  listCategories:  () => api.get('/admin/blog/categories/'),
  createCategory:  (d) => api.post('/admin/blog/categories/', d),
  deleteCategory:  (id) => api.delete(`/admin/blog/categories/${id}/`),
};

// ══════════════════════════════
// BLOG MANAGER — main list
// ══════════════════════════════
export default function BlogManager() {
  const queryClient = useQueryClient();
  const [view, setView] = useState('list'); // list | editor
  const [editingPost, setEditingPost] = useState(null);
  const [statusFilter, setStatusFilter] = useState('all');

  const { data, isLoading } = useQuery({
    queryKey: ['admin-blog', statusFilter],
    queryFn: () => blogApi.listPosts(statusFilter !== 'all' ? { status: statusFilter } : {}),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => blogApi.deletePost(id),
    onSuccess: () => { queryClient.invalidateQueries(['admin-blog']); toast.success('Post deleted'); },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: ({ id, status }) => {
      const fd = new FormData(); fd.append('status', status);
      return blogApi.updatePost(id, fd);
    },
    onSuccess: () => { queryClient.invalidateQueries(['admin-blog']); toast.success('Status updated'); },
  });

  const posts = data?.data?.data || [];

  if (view === 'editor') {
    return (
      <BlogEditor
        post={editingPost}
        onBack={() => { setView('list'); setEditingPost(null); }}
      />
    );
  }

  return (
    <div className="admin-blog">
      <div className="admin-page-header">
        <div>
          <h1 className="admin-page-title">Blog</h1>
          <p className="admin-page-sub">{posts.length} posts</p>
        </div>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <CategoryManager />
          <button className="btn-admin-primary" onClick={() => { setEditingPost(null); setView('editor'); }}>
            + New Post
          </button>
        </div>
      </div>

      {/* Filter */}
      <div className="filter-tabs" style={{ marginBottom: '20px' }}>
        {['all', 'published', 'draft'].map((f) => (
          <button key={f} className={`filter-tab ${statusFilter === f ? 'active' : ''}`} onClick={() => setStatusFilter(f)}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="loading-rows">{[1,2,3].map(i => <div key={i} className="skeleton-row" />)}</div>
      ) : (
        <div className="blog-posts-list">
          {posts.map((post) => (
            <div key={post.id} className="blog-post-row">
              <div className="blog-post-thumb">
                {post.thumbnail
                  ? <img src={post.thumbnail} alt={post.title} />
                  : <div className="thumb-placeholder">✍️</div>}
              </div>
              <div className="blog-post-info">
                <div className="blog-post-title">{post.title}</div>
                <div className="blog-post-meta">
                  {post.categories?.map(c => (
                    <span key={c.id} className="category-chip">{c.name}</span>
                  ))}
                  <span className="blog-post-date">
                    {post.published_at
                      ? new Date(post.published_at).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' })
                      : 'Not published'}
                  </span>
                </div>
                <div className="blog-post-excerpt">{post.excerpt}</div>
              </div>
              <div className="blog-post-actions">
                <span className={`status-badge ${post.status === 'published' ? 'active' : 'inactive'}`}>
                  {post.status}
                </span>
                <button
                  className="action-btn"
                  onClick={() => toggleStatusMutation.mutate({
                    id: post.id,
                    status: post.status === 'published' ? 'draft' : 'published',
                  })}
                >
                  {post.status === 'published' ? '⏸ Unpublish' : '▶ Publish'}
                </button>
                <button className="action-btn" onClick={() => { setEditingPost(post); setView('editor'); }}>
                  ✏️ Edit
                </button>
                <button
                  className="action-btn delete"
                  onClick={() => { if (confirm('Delete this post?')) deleteMutation.mutate(post.id); }}
                >
                  🗑
                </button>
              </div>
            </div>
          ))}
          {posts.length === 0 && <div className="empty-state"><div className="empty-icon">✍️</div><p>No posts yet</p></div>}
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════
// BLOG EDITOR
// ══════════════════════════════
function BlogEditor({ post, onBack }) {
  const queryClient = useQueryClient();
  const isEditing = !!post;

  const [title, setTitle] = useState(post?.title || '');
  const [content, setContent] = useState(post?.content || '');
  const [excerpt, setExcerpt] = useState(post?.excerpt || '');
  const [status, setStatus] = useState(post?.status || 'draft');
  const [thumbnail, setThumbnail] = useState(null);
  const [thumbnailPreview, setThumbnailPreview] = useState(post?.thumbnail || null);
  const [activeTab, setActiveTab] = useState('write'); // write | preview

  const { data: catData } = useQuery({ queryKey: ['categories'], queryFn: blogApi.listCategories });
  const categories = catData?.data?.data || [];
  const [selectedCats, setSelectedCats] = useState(post?.categories?.map(c => c.id) || []);

  const saveMutation = useMutation({
    mutationFn: (fd) => isEditing ? blogApi.updatePost(post.id, fd) : blogApi.createPost(fd),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-blog']);
      toast.success(isEditing ? 'Post updated!' : 'Post created!');
      onBack();
    },
    onError: () => toast.error('Save failed'),
  });

  const handleThumbnail = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setThumbnail(file);
    setThumbnailPreview(URL.createObjectURL(file));
  };

  const handleSave = (publishNow = false) => {
    if (!title.trim()) { toast.error('Title is required'); return; }
    if (!content.trim()) { toast.error('Content is required'); return; }

    const fd = new FormData();
    fd.append('title', title);
    fd.append('content', content);
    fd.append('excerpt', excerpt);
    fd.append('status', publishNow ? 'published' : status);
    if (thumbnail) fd.append('thumbnail', thumbnail);
    selectedCats.forEach(id => fd.append('category_ids', id));
    saveMutation.mutate(fd);
  };

  const toggleCat = (id) =>
    setSelectedCats(prev => prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]);

  // Simple markdown-like preview
  const renderPreview = (text) => text
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^/, '<p>')
    .replace(/$/, '</p>');

  return (
    <div className="blog-editor">
      {/* Header */}
      <div className="editor-header">
        <button className="back-link" onClick={onBack}>← All Posts</button>
        <div className="editor-header-title">
          {isEditing ? 'Edit Post' : 'New Post'}
        </div>
        <div className="editor-actions">
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="status-select"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
          <button
            className="btn-outline-gold"
            onClick={() => handleSave(false)}
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? 'Saving...' : 'Save Draft'}
          </button>
          <button
            className="btn-admin-primary"
            onClick={() => handleSave(true)}
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? 'Publishing...' : '▶ Publish'}
          </button>
        </div>
      </div>

      <div className="editor-layout">
        {/* Main editor area */}
        <div className="editor-main">
          <input
            className="editor-title-input"
            placeholder="Post title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          {/* Write / Preview tabs */}
          <div className="editor-tabs">
            <button className={`editor-tab ${activeTab === 'write' ? 'active' : ''}`} onClick={() => setActiveTab('write')}>
              ✏️ Write
            </button>
            <button className={`editor-tab ${activeTab === 'preview' ? 'active' : ''}`} onClick={() => setActiveTab('preview')}>
              👁 Preview
            </button>
            <div className="editor-tab-hint">Markdown supported</div>
          </div>

          {activeTab === 'write' ? (
            <textarea
              className="editor-textarea"
              placeholder={`Write your post content here...\n\n# Heading 1\n## Heading 2\n**bold** *italic*\n\nParagraphs separated by blank lines.`}
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          ) : (
            <div
              className="editor-preview"
              dangerouslySetInnerHTML={{ __html: renderPreview(content) }}
            />
          )}

          <textarea
            className="editor-excerpt"
            placeholder="Short excerpt (auto-generated if blank)..."
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            rows={3}
          />
        </div>

        {/* Sidebar */}
        <div className="editor-sidebar">
          {/* Thumbnail */}
          <div className="editor-sidebar-section">
            <div className="sidebar-section-title">Thumbnail</div>
            <label className="thumbnail-upload">
              {thumbnailPreview ? (
                <img src={thumbnailPreview} alt="Thumbnail" className="thumbnail-preview" />
              ) : (
                <div className="thumbnail-placeholder">
                  <span>🖼</span>
                  <span>Upload image</span>
                </div>
              )}
              <input type="file" accept="image/*" onChange={handleThumbnail} style={{ display: 'none' }} />
            </label>
            {thumbnailPreview && (
              <button
                className="btn-sm-danger"
                onClick={() => { setThumbnail(null); setThumbnailPreview(null); }}
              >
                Remove
              </button>
            )}
          </div>

          {/* Categories */}
          <div className="editor-sidebar-section">
            <div className="sidebar-section-title">Categories</div>
            <div className="categories-list">
              {categories.map((cat) => (
                <label key={cat.id} className="category-checkbox">
                  <input
                    type="checkbox"
                    checked={selectedCats.includes(cat.id)}
                    onChange={() => toggleCat(cat.id)}
                  />
                  <span>{cat.name}</span>
                </label>
              ))}
              {categories.length === 0 && (
                <p style={{ fontSize: '12px', color: 'var(--text-3)' }}>No categories yet</p>
              )}
            </div>
          </div>

          {/* Word count */}
          <div className="editor-sidebar-section">
            <div className="sidebar-section-title">Stats</div>
            <div className="editor-stats">
              <div className="editor-stat">
                <span>{content.split(/\s+/).filter(Boolean).length}</span>
                <span>words</span>
              </div>
              <div className="editor-stat">
                <span>{Math.max(1, Math.round(content.split(/\s+/).filter(Boolean).length / 200))}</span>
                <span>min read</span>
              </div>
              <div className="editor-stat">
                <span>{content.length}</span>
                <span>chars</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════
// CATEGORY MANAGER (modal)
// ══════════════════════════════
function CategoryManager() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [newName, setNewName] = useState('');

  const { data } = useQuery({ queryKey: ['categories'], queryFn: blogApi.listCategories, enabled: open });
  const categories = data?.data?.data || [];

  const createMutation = useMutation({
    mutationFn: () => blogApi.createCategory({ name: newName, slug: newName.toLowerCase().replace(/\s+/g, '-') }),
    onSuccess: () => { queryClient.invalidateQueries(['categories']); setNewName(''); toast.success('Category created'); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => blogApi.deleteCategory(id),
    onSuccess: () => { queryClient.invalidateQueries(['categories']); toast.success('Category deleted'); },
  });

  if (!open) return (
    <button className="btn-outline-gold" onClick={() => setOpen(true)}>🏷 Categories</button>
  );

  return (
    <div className="modal-overlay" onClick={() => setOpen(false)}>
      <div className="modal-box" style={{ maxWidth: '400px', width: '100%', padding: '28px' }} onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={() => setOpen(false)}>✕</button>
        <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, marginBottom: '20px' }}>Categories</h3>
        <div className="cat-create-row">
          <input
            className="cat-input"
            placeholder="New category name..."
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && newName && createMutation.mutate()}
          />
          <button
            className="btn-admin-primary"
            onClick={() => newName && createMutation.mutate()}
            disabled={!newName || createMutation.isPending}
          >Add</button>
        </div>
        <div className="cat-list">
          {categories.map(cat => (
            <div key={cat.id} className="cat-item">
              <span>{cat.name}</span>
              <button className="cat-delete" onClick={() => deleteMutation.mutate(cat.id)}>✕</button>
            </div>
          ))}
          {categories.length === 0 && <p style={{ color: 'var(--text-3)', fontSize: '13px', textAlign: 'center', padding: '20px 0' }}>No categories yet</p>}
        </div>
      </div>
    </div>
  );
}
