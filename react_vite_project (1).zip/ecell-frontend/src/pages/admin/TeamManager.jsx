import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '../../api/axiosInstance';
import toast from 'react-hot-toast';

const teamApi = {
  list:   (p) => api.get('/admin/team/', { params: p }),
  create: (fd) => api.post('/admin/team/', fd, { headers: { 'Content-Type': 'multipart/form-data' } }),
  update: (id, fd) => api.patch(`/admin/team/${id}/`, fd, { headers: { 'Content-Type': 'multipart/form-data' } }),
  remove: (id) => api.delete(`/admin/team/${id}/`),
};

const WINGS = [
  { key: 'tech',        label: 'Tech',         icon: '⚙️' },
  { key: 'design',      label: 'Design',        icon: '🎨' },
  { key: 'startup',     label: 'Start-Up',      icon: '🚀' },
  { key: 'events',      label: 'Event Mgmt',    icon: '🎪' },
  { key: 'media',       label: 'Media',         icon: '🎥' },
  { key: 'marketing',   label: 'Marketing',     icon: '📢' },
  { key: 'socialmedia', label: 'Social Media',  icon: '📱' },
  { key: 'finance',     label: 'Finance',       icon: '📊' },
  { key: 'sponsorship', label: 'Sponsorship',   icon: '🤝' },
  { key: 'research',    label: 'Research',      icon: '🔬' },
];

export default function TeamManager() {
  const queryClient = useQueryClient();
  const [activeWing, setActiveWing] = useState('tech');
  const [showForm, setShowForm] = useState(false);
  const [editingMember, setEditingMember] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['admin-team', activeWing],
    queryFn: () => teamApi.list({ wing: activeWing }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => teamApi.remove(id),
    onSuccess: () => { queryClient.invalidateQueries(['admin-team']); toast.success('Member removed'); },
  });

  const members = data?.data?.data || [];
  const wingInfo = WINGS.find(w => w.key === activeWing);

  return (
    <div className="team-manager">
      <div className="admin-page-header">
        <div>
          <h1 className="admin-page-title">Team</h1>
          <p className="admin-page-sub">Manage all team members by department</p>
        </div>
        <button
          className="btn-admin-primary"
          onClick={() => { setEditingMember(null); setShowForm(true); }}
        >
          + Add Member
        </button>
      </div>

      {/* Wing tabs */}
      <div className="wing-tabs">
        {WINGS.map(w => (
          <button
            key={w.key}
            className={`wing-tab ${activeWing === w.key ? 'active' : ''}`}
            onClick={() => setActiveWing(w.key)}
          >
            {w.icon} {w.label}
          </button>
        ))}
      </div>

      {/* Member count bar */}
      <div className="team-count-bar" style={{ marginBottom: '20px' }}>
        {wingInfo?.icon} {wingInfo?.label} Team ·{' '}
        <span>{isLoading ? '…' : members.length}</span> members
      </div>

      {isLoading ? (
        <div className="members-grid">
          {[1,2,3,4,5,6].map(i => <div key={i} className="skeleton-card" style={{ height: '200px' }} />)}
        </div>
      ) : (
        <div className="members-grid">
          {members.map(member => (
            <MemberCard
              key={member.id}
              member={member}
              onEdit={() => { setEditingMember(member); setShowForm(true); }}
              onDelete={() => { if (confirm(`Remove ${member.full_name}?`)) deleteMutation.mutate(member.id); }}
            />
          ))}
          {/* Add placeholder card */}
          <div
            className="member-card add-card"
            onClick={() => { setEditingMember(null); setShowForm(true); }}
          >
            <div className="add-card-icon">+</div>
            <div className="add-card-label">Add {wingInfo?.label} member</div>
          </div>
        </div>
      )}

      {/* Add / Edit modal */}
      {showForm && (
        <MemberForm
          member={editingMember}
          defaultWing={activeWing}
          onClose={() => { setShowForm(false); setEditingMember(null); }}
          onSaved={() => {
            queryClient.invalidateQueries(['admin-team']);
            setShowForm(false);
            setEditingMember(null);
          }}
        />
      )}
    </div>
  );
}

// ─── Member Card ───
function MemberCard({ member, onEdit, onDelete }) {
  return (
    <div className="member-card">
      <div className="member-card-avatar">
        {member.photo
          ? <img src={member.photo} alt={member.full_name} />
          : <div className="avatar-initials">{member.full_name.split(' ').map(n => n[0]).join('').slice(0,2)}</div>}
      </div>
      <div className="member-card-name">{member.full_name}</div>
      <div className="member-card-role">{member.role}</div>
      <div className="member-card-wing">{WINGS.find(w => w.key === member.wing)?.icon} {member.wing}</div>
      {member.linkedin_url && (
        <a href={member.linkedin_url} target="_blank" rel="noreferrer" className="member-linkedin">
          LinkedIn →
        </a>
      )}
      {!member.is_active && <div className="member-inactive-badge">Inactive</div>}
      <div className="member-card-actions">
        <button className="action-btn" onClick={onEdit}>✏️ Edit</button>
        <button className="action-btn delete" onClick={onDelete}>🗑</button>
      </div>
    </div>
  );
}

// ─── Add / Edit Form Modal ───
function MemberForm({ member, defaultWing, onClose, onSaved }) {
  const isEditing = !!member;
  const [form, setForm] = useState({
    full_name:      member?.full_name || '',
    role:           member?.role || '',
    wing:           member?.wing || defaultWing,
    linkedin_url:   member?.linkedin_url || '',
    display_order:  member?.display_order ?? 0,
    is_active:      member?.is_active ?? true,
  });
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(member?.photo || null);
  const [saving, setSaving] = useState(false);

  const handleChange = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.full_name || !form.role) { toast.error('Name and role are required'); return; }
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (photo) fd.append('photo', photo);
      if (isEditing) await teamApi.update(member.id, fd);
      else await teamApi.create(fd);
      toast.success(isEditing ? 'Member updated!' : 'Member added!');
      onSaved();
    } catch {
      toast.error('Save failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: '520px', width: '100%' }} onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>
        <div style={{ padding: '32px' }}>
          <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '20px', marginBottom: '24px' }}>
            {isEditing ? 'Edit Member' : 'Add Member'}
          </h3>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* Photo upload */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <label style={{ cursor: 'pointer' }}>
                <div className="form-avatar-upload">
                  {photoPreview
                    ? <img src={photoPreview} alt="" style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover' }} />
                    : <div className="form-avatar-placeholder">📷</div>}
                </div>
                <input type="file" accept="image/*" onChange={handlePhoto} style={{ display: 'none' }} />
              </label>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: '13px', color: 'var(--text-2)' }}>Profile photo</p>
                <p style={{ fontSize: '11px', color: 'var(--text-3)', marginTop: '3px' }}>Click to upload (optional)</p>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Full Name *</label>
                <input className="form-input" value={form.full_name} onChange={e => handleChange('full_name', e.target.value)} required />
              </div>
              <div className="form-group">
                <label className="form-label">Role *</label>
                <input className="form-input" placeholder="e.g. Tech Lead" value={form.role} onChange={e => handleChange('role', e.target.value)} required />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Department (Wing)</label>
                <select className="form-input" value={form.wing} onChange={e => handleChange('wing', e.target.value)}>
                  {WINGS.map(w => <option key={w.key} value={w.key}>{w.icon} {w.label}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Display Order</label>
                <input className="form-input" type="number" min="0" value={form.display_order} onChange={e => handleChange('display_order', +e.target.value)} />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">LinkedIn URL</label>
              <input className="form-input" placeholder="https://linkedin.com/in/..." value={form.linkedin_url} onChange={e => handleChange('linkedin_url', e.target.value)} />
            </div>

            <label className="form-checkbox">
              <input type="checkbox" checked={form.is_active} onChange={e => handleChange('is_active', e.target.checked)} />
              <span>Active member (visible on website)</span>
            </label>

            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '8px' }}>
              <button type="button" className="btn-outline-gold" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn-admin-primary" disabled={saving}>
                {saving ? 'Saving...' : isEditing ? 'Update Member' : 'Add Member'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
