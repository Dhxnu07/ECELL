import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '../../api/services';
import toast from 'react-hot-toast';

// ─── Utility: trigger file download from blob ───
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ══════════════════════════════
// ADMIN DASHBOARD
// ══════════════════════════════
export function AdminDashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: () => adminApi.stats(),
    refetchInterval: 30000, // refresh every 30s
  });

  const stats = data?.data?.data || {};

  const statCards = [
    { label: 'Total Registrations', value: stats.total_registrations ?? '—', icon: '👥', color: 'blue' },
    { label: 'Active Events', value: stats.active_events ?? '—', icon: '📅', color: 'green' },
    { label: 'Pending Pitches', value: stats.pending_pitches ?? '—', icon: '💡', color: 'amber' },
    { label: 'Blog Posts', value: stats.total_blog_posts ?? '—', icon: '✍️', color: 'purple' },
  ];

  return (
    <div className="admin-dashboard">
      <div className="admin-page-header">
        <h1 className="admin-page-title">Dashboard</h1>
        <p className="admin-page-sub">Welcome back, Admin</p>
      </div>

      <div className="stats-grid">
        {statCards.map((s) => (
          <div key={s.label} className={`stat-card stat-${s.color}`}>
            <div className="stat-card-icon">{s.icon}</div>
            <div className="stat-card-value">
              {isLoading ? <span className="skeleton-text" /> : s.value}
            </div>
            <div className="stat-card-label">{s.label}</div>
          </div>
        ))}
      </div>

      {stats.recent_activity?.length > 0 && (
        <div className="activity-feed">
          <h3 className="section-heading">Recent Activity</h3>
          <div className="activity-list">
            {stats.recent_activity.map((item, i) => (
              <div key={i} className="activity-item">
                <div className="activity-dot" />
                <div className="activity-text">{item.message}</div>
                <div className="activity-time">{item.time}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════
// EVENTS MANAGER
// ══════════════════════════════
export function AdminEventsManager() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['admin-events'],
    queryFn: () => adminApi.listEvents(),
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, is_active }) => adminApi.updateEvent(id, { is_active }),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-events']);
      toast.success('Event updated');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => adminApi.deleteEvent(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-events']);
      toast.success('Event deleted');
    },
  });

  const events = data?.data?.data || [];

  return (
    <div className="admin-events">
      <div className="admin-page-header">
        <div>
          <h1 className="admin-page-title">Events</h1>
          <p className="admin-page-sub">{events.length} total events</p>
        </div>
        <button className="btn-admin-primary" onClick={() => setShowForm(true)}>
          + New Event
        </button>
      </div>

      {isLoading ? (
        <div className="loading-rows">
          {[1, 2, 3].map((i) => <div key={i} className="skeleton-row" />)}
        </div>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Event</th>
                <th>Date</th>
                <th>Venue</th>
                <th>Registrations</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {events.map((event) => (
                <tr key={event.id}>
                  <td>
                    <div className="table-event-name">{event.title}</div>
                    <div className="table-event-slug">{event.slug}</div>
                  </td>
                  <td>
                    {new Date(event.start_datetime).toLocaleDateString('en-IN', {
                      day: 'numeric', month: 'short', year: 'numeric',
                    })}
                  </td>
                  <td>{event.venue}</td>
                  <td>
                    <span className="reg-count">{event.registered_count ?? 0}</span>
                    {event.max_capacity && <span className="reg-max">/{event.max_capacity}</span>}
                  </td>
                  <td>
                    <span className={`status-badge ${event.is_active ? 'active' : 'inactive'}`}>
                      {event.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="table-actions">
                      <button
                        className="action-btn scan"
                        onClick={() => window.location.href = `/admin/events/${event.id}/scan`}
                        title="QR Scanner"
                      >
                        📷 Scan
                      </button>
                      <ExportButton eventId={event.id} eventTitle={event.title} />
                      <button
                        className="action-btn toggle"
                        onClick={() => toggleActiveMutation.mutate({ id: event.id, is_active: !event.is_active })}
                        title={event.is_active ? 'Deactivate' : 'Activate'}
                      >
                        {event.is_active ? '⏸' : '▶'}
                      </button>
                      <button
                        className="action-btn delete"
                        onClick={() => {
                          if (confirm('Delete this event?')) deleteMutation.mutate(event.id);
                        }}
                        title="Delete"
                      >
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Registrations drawer */}
      {selectedEvent && (
        <RegistrationsDrawer
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  );
}

// ══════════════════════════════
// EXPORT BUTTON — component 4
// ══════════════════════════════
export function ExportButton({ eventId, eventTitle }) {
  const [exporting, setExporting] = useState(false);
  const [type, setType] = useState(null);

  const handleExport = async (exportType) => {
    setExporting(true);
    setType(exportType);
    try {
      const res = exportType === 'pre'
        ? await adminApi.exportPre(eventId)
        : await adminApi.exportPost(eventId);

      const filename = `${eventTitle}_${exportType === 'pre' ? 'registrations' : 'attendance'}.xlsx`;
      downloadBlob(res.data, filename);
      toast.success(`Downloaded ${filename}`);
    } catch {
      toast.error('Export failed. Try again.');
    } finally {
      setExporting(false);
      setType(null);
    }
  };

  return (
    <div className="export-dropdown">
      <button className="action-btn export" title="Export">
        {exporting ? '⏳' : '⬇'} Export
      </button>
      <div className="export-menu">
        <button
          className="export-item"
          onClick={() => handleExport('pre')}
          disabled={exporting}
        >
          <span>📋</span>
          <div>
            <div className="export-item-title">Pre-event list</div>
            <div className="export-item-sub">Name, USN, Email, Department</div>
          </div>
        </button>
        <button
          className="export-item"
          onClick={() => handleExport('post')}
          disabled={exporting}
        >
          <span>✅</span>
          <div>
            <div className="export-item-title">Post-event attendance</div>
            <div className="export-item-sub">+ Attended status, timestamp</div>
          </div>
        </button>
      </div>
    </div>
  );
}

// ══════════════════════════════
// REGISTRATIONS DRAWER
// ══════════════════════════════
function RegistrationsDrawer({ event, onClose }) {
  const { data, isLoading } = useQuery({
    queryKey: ['registrations', event.id],
    queryFn: () => adminApi.listRegistrations(event.id),
  });

  const registrations = data?.data?.data || [];

  return (
    <div className="drawer-overlay" onClick={onClose}>
      <div className="drawer" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <div>
            <h3 className="drawer-title">Registrations</h3>
            <p className="drawer-sub">{event.title}</p>
          </div>
          <div className="drawer-header-actions">
            <ExportButton eventId={event.id} eventTitle={event.title} />
            <button className="drawer-close" onClick={onClose}>✕</button>
          </div>
        </div>

        {isLoading ? (
          <div className="drawer-loading"><div className="spinner" /></div>
        ) : (
          <div className="registrations-table-wrap">
            <table className="admin-table compact">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>USN</th>
                  <th>Department</th>
                  <th>Email</th>
                  <th>Attended</th>
                </tr>
              </thead>
              <tbody>
                {registrations.map((r, i) => (
                  <tr key={r.id}>
                    <td className="reg-id">#{r.id}</td>
                    <td>{r.name}</td>
                    <td>{r.usn}</td>
                    <td>{r.department}</td>
                    <td>{r.email}</td>
                    <td>
                      <span className={`attend-badge ${r.attended ? 'yes' : 'no'}`}>
                        {r.attended ? '✓ Present' : '✗ Absent'}
                      </span>
                    </td>
                  </tr>
                ))}
                {registrations.length === 0 && (
                  <tr>
                    <td colSpan={6} className="empty-row">No registrations yet</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
