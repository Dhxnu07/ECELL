import { useEffect, useRef, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { Html5Qrcode } from 'html5-qrcode';
import { adminApi } from '../../api/services';
import toast from 'react-hot-toast';

export default function QrScanPage() {
  const { id: eventId } = useParams();
  const scannerRef = useRef(null);
  const lastTokenRef = useRef(null);
  const debounceRef = useRef(null);
  const [scannerReady, setScannerReady] = useState(false);
  const [lastResult, setLastResult] = useState(null); // { type: 'success'|'error'|'duplicate', data }
  const [scanCount, setScanCount] = useState(0);

  const scanMutation = useMutation({
    mutationFn: (token) => adminApi.scanQr(eventId, token),
    onSuccess: (res) => {
      const data = res.data?.data || res.data;
      setScanCount((c) => c + 1);
      if (data.already_attended) {
        setLastResult({ type: 'duplicate', data });
        toast.error(`Already checked in: ${data.name}`);
      } else {
        setLastResult({ type: 'success', data });
        toast.success(`✓ Checked in: ${data.name} (${data.usn})`);
      }
    },
    onError: (err) => {
      const msg = err.response?.data?.detail || 'Invalid QR code';
      setLastResult({ type: 'error', msg });
      toast.error(msg);
    },
  });

  useEffect(() => {
    const scanner = new Html5Qrcode('qr-reader');
    scannerRef.current = scanner;

    scanner
      .start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        (decodedText) => {
          // Debounce: ignore same token within 3 seconds
          if (lastTokenRef.current === decodedText) return;
          if (debounceRef.current) clearTimeout(debounceRef.current);

          lastTokenRef.current = decodedText;
          scanMutation.mutate(decodedText);

          debounceRef.current = setTimeout(() => {
            lastTokenRef.current = null;
          }, 3000);
        },
        () => {} // ignore decode errors (camera noise)
      )
      .then(() => setScannerReady(true))
      .catch((err) => toast.error('Camera error: ' + err));

    return () => {
      if (scannerRef.current?.isScanning) {
        scannerRef.current.stop().catch(() => {});
      }
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [eventId]);

  return (
    <div className="scanner-page">
      <div className="scanner-header">
        <a href="/admin/events" className="back-link">← Back to Events</a>
        <h1 className="scanner-title">QR Scanner</h1>
        <div className="scan-counter">{scanCount} checked in</div>
      </div>

      <div className="scanner-layout">
        {/* Camera feed */}
        <div className="scanner-box">
          <div className="scanner-frame">
            <div id="qr-reader" />
            {!scannerReady && (
              <div className="scanner-loading">
                <div className="spinner" />
                <p>Starting camera...</p>
              </div>
            )}
            {/* Scanning corners animation */}
            <div className="scan-corner top-left" />
            <div className="scan-corner top-right" />
            <div className="scan-corner bottom-left" />
            <div className="scan-corner bottom-right" />
            <div className="scan-line" />
          </div>
          <p className="scanner-hint">Point camera at student's QR ticket</p>
        </div>

        {/* Last scan result */}
        <div className="scanner-result-panel">
          <h3 className="result-panel-title">Last Scan</h3>

          {!lastResult && (
            <div className="result-empty">
              <div className="result-icon idle">⬡</div>
              <p>Waiting for scan...</p>
            </div>
          )}

          {lastResult?.type === 'success' && (
            <div className="result-card success">
              <div className="result-icon success">✓</div>
              <div className="result-name">{lastResult.data.name}</div>
              <div className="result-detail">{lastResult.data.usn}</div>
              <div className="result-detail">{lastResult.data.department}</div>
              <div className="result-time">
                {new Date(lastResult.data.attended_at).toLocaleTimeString('en-IN')}
              </div>
              <div className="result-badge success">Checked In</div>
            </div>
          )}

          {lastResult?.type === 'duplicate' && (
            <div className="result-card duplicate">
              <div className="result-icon duplicate">⚠</div>
              <div className="result-name">{lastResult.data.name}</div>
              <div className="result-detail">{lastResult.data.usn}</div>
              <div className="result-time">
                Already checked in at{' '}
                {new Date(lastResult.data.attended_at).toLocaleTimeString('en-IN')}
              </div>
              <div className="result-badge duplicate">Already Scanned</div>
            </div>
          )}

          {lastResult?.type === 'error' && (
            <div className="result-card error">
              <div className="result-icon error">✕</div>
              <div className="result-name">Invalid QR</div>
              <div className="result-detail">{lastResult.msg}</div>
              <div className="result-badge error">Failed</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
