import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { eventsApi } from '../../api/services';
import useAuthStore from '../../store/authStore';
import toast from 'react-hot-toast';
import TicketModal from '../../components/events/TicketModal';

export default function Events() {
  const { isAuthenticated } = useAuthStore();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState('all'); // all | upcoming | past
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [ticketSlug, setTicketSlug] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['events', filter],
    queryFn: () => eventsApi.list(filter !== 'all' ? { [filter]: true } : {}),
  });

  const registerMutation = useMutation({
    mutationFn: (slug) => eventsApi.register(slug),
    onSuccess: (_, slug) => {
      toast.success('Registered! Check your email for your QR ticket.');
      queryClient.invalidateQueries(['events']);
      setTicketSlug(slug);
    },
    onError: (err) => {
      const msg = err.response?.data?.detail || 'Registration failed';
      toast.error(msg);
    },
  });

  const events = data?.data || [];

  return (
    <div className="events-page">
      <div className="events-header">
        <div>
          <div className="page-eyebrow">NMAMIT E-Cell</div>
          <h1 className="page-title">Events</h1>
          <p className="page-sub">Workshops, hackathons, speaker sessions & more</p>
        </div>
        <div className="filter-tabs">
          {['all', 'upcoming', 'past'].map((f) => (
            <button
              key={f}
              className={`filter-tab ${filter === f ? 'active' : ''}`}
              onClick={() => setFilter(f)}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="loading-grid">
          {[1, 2, 3].map((i) => <div key={i} className="skeleton-card" />)}
        </div>
      ) : events.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📅</div>
          <p>No events found</p>
        </div>
      ) : (
        <div className="events-grid">
          {events.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              isAuthenticated={isAuthenticated}
              onRegister={() => registerMutation.mutate(event.slug)}
              onViewTicket={() => setTicketSlug(event.slug)}
              isRegistering={registerMutation.isPending}
              onClick={() => setSelectedEvent(event)}
            />
          ))}
        </div>
      )}

      {/* Event Detail Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          isAuthenticated={isAuthenticated}
          onRegister={() => {
            registerMutation.mutate(selectedEvent.slug);
            setSelectedEvent(null);
          }}
          isRegistering={registerMutation.isPending}
        />
      )}

      {/* Ticket / QR Modal */}
      {ticketSlug && (
        <TicketModal slug={ticketSlug} onClose={() => setTicketSlug(null)} />
      )}
    </div>
  );
}

function EventCard({ event, isAuthenticated, onRegister, onViewTicket, isRegistering, onClick }) {
  const isPast = new Date(event.start_datetime) < new Date();
  const isFull = event.max_capacity && event.registered_count >= event.max_capacity;

  return (
    <div className="event-card" onClick={onClick}>
      <div className="event-card-thumb">
        {event.banner_image ? (
          <img src={event.banner_image} alt={event.title} />
        ) : (
          <div className="event-thumb-placeholder">📅</div>
        )}
        <span className={`event-badge ${isPast ? 'past' : 'upcoming'}`}>
          {isPast ? 'Past' : 'Upcoming'}
        </span>
      </div>
      <div className="event-card-body">
        <div className="event-meta-row">
          <span className="event-date">
            {new Date(event.start_datetime).toLocaleDateString('en-IN', {
              day: 'numeric', month: 'short', year: 'numeric',
            })}
          </span>
          <span className="event-venue">📍 {event.venue}</span>
        </div>
        <h3 className="event-title">{event.title}</h3>
        <p className="event-desc">{event.description?.replace(/<[^>]*>/g, '').slice(0, 100)}...</p>
        <div className="event-card-footer" onClick={(e) => e.stopPropagation()}>
          {event.max_capacity && (
            <div className="capacity-bar">
              <div
                className="capacity-fill"
                style={{ width: `${Math.min((event.registered_count / event.max_capacity) * 100, 100)}%` }}
              />
              <span className="capacity-text">
                {event.registered_count}/{event.max_capacity} seats
              </span>
            </div>
          )}
          {event.user_registered ? (
            <button className="btn-ticket" onClick={onViewTicket}>
              View My Ticket →
            </button>
          ) : isPast ? (
            <button className="btn-disabled" disabled>Event Ended</button>
          ) : isFull ? (
            <button className="btn-disabled" disabled>Full</button>
          ) : isAuthenticated ? (
            <button
              className="btn-register"
              onClick={onRegister}
              disabled={isRegistering}
            >
              {isRegistering ? 'Registering...' : 'Register Now'}
            </button>
          ) : (
            <a href="/login" className="btn-login">Login to Register</a>
          )}
        </div>
      </div>
    </div>
  );
}

function EventDetailModal({ event, onClose, isAuthenticated, onRegister, isRegistering }) {
  const isPast = new Date(event.start_datetime) < new Date();

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box event-detail-modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>
        {event.banner_image && (
          <img src={event.banner_image} alt={event.title} className="modal-banner" />
        )}
        <div className="modal-content">
          <div className="event-meta-row">
            <span className="event-date">
              {new Date(event.start_datetime).toLocaleString('en-IN')}
            </span>
            <span className="event-venue">📍 {event.venue}</span>
          </div>
          <h2 className="modal-title">{event.title}</h2>
          <div
            className="event-description"
            dangerouslySetInnerHTML={{ __html: event.description }}
          />
          {event.speakers?.length > 0 && (
            <div className="speakers-section">
              <h4>Speakers</h4>
              <div className="speakers-list">
                {event.speakers.map((s, i) => (
                  <div key={i} className="speaker-chip">
                    {s.photo_url && <img src={s.photo_url} alt={s.name} />}
                    <div>
                      <div className="speaker-name">{s.name}</div>
                      <div className="speaker-bio">{s.bio}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div className="modal-footer">
            {event.user_registered ? (
              <div className="already-registered">✓ You're registered for this event</div>
            ) : !isPast && isAuthenticated && (
              <button
                className="btn-register large"
                onClick={onRegister}
                disabled={isRegistering}
              >
                {isRegistering ? 'Registering...' : 'Register for this Event'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
