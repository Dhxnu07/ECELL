import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { create } from 'zustand';
import api from '../../api/axiosInstance';

// ─── Notification API ───
const notifApi = {
  list:    () => api.get('/admin/notifications/'),
  markOne: (id) => api.patch(`/admin/notifications/${id}/read/`),
  markAll: () => api.patch('/admin/notifications/read-all/'),
};

// ─── Zustand store for unread count ───
export const useNotifStore = create((set) => ({
  unreadCount: 0,
  setUnreadCount: (n) => set({ unreadCount: n }),
}));

// ══════════════════════════════
// NOTIFICATION BELL — top nav
// ══════════════════════════════
export function NotificationBell() {
  const queryClient = useQueryClient();
  const { unreadCount, setUnreadCount } = useNotifStore();
  const [open, setOpen] = useState(false);

  // Poll every 30 seconds
  const { data } = useQuery({
    queryKey: ['admin-notifications'],
    queryFn: notifApi.list,
    refetchInterval: 30000,
    refetchIntervalInBackground: true,
  });

  const notifications = data?.data?.data || [];
  const unread = notifications.filter(n => !n.is_read);

  useEffect(() => {
    setUnreadCount(unread.length);
  }, [unread.length]);

  const markOneMutation = useMutation({
    mutationFn: (id) => notifApi.markOne(id),
    onSuccess: () => queryClient.invalidateQueries(['admin-notifications']),
  });

  const markAllMutation = useMutation({
    mutationFn: notifApi.markAll,
    onSuccess: () => queryClient.invalidateQueries(['admin-notifications']),
  });

  return (
    <div className="notif-bell-wrap">
      <button className="notif-bell" onClick={() => setOpen(!open)}>
        🔔
        {unreadCount > 0 && (
          <span className="notif-badge">{unreadCount > 9 ? '9+' : unreadCount}</span>
        )}
      </button>

      {open && (
        <>
          <div className="notif-overlay" onClick={() => setOpen(false)} />
          <div className="notif-drawer">
            <div className="notif-drawer-header">
              <span className="notif-drawer-title">Notifications</span>
              {unread.length > 0 && (
                <button
                  className="notif-mark-all"
                  onClick={() => markAllMutation.mutate()}
                  disabled={markAllMutation.isPending}
                >
                  Mark all read
                </button>
              )}
            </div>

            <div className="notif-list">
              {notifications.length === 0 && (
                <div className="notif-empty">
                  <div style={{ fontSize: '28px', marginBottom: '8px' }}>🔕</div>
                  <p>No notifications</p>
                </div>
              )}
              {notifications.map(n => (
                <div
                  key={n.id}
                  className={`notif-item ${!n.is_read ? 'unread' : ''}`}
                  onClick={() => !n.is_read && markOneMutation.mutate(n.id)}
                >
                  <div className="notif-type-icon">{getNotifIcon(n.type)}</div>
                  <div className="notif-content">
                    <div className="notif-title">{n.title}</div>
                    <div className="notif-body">{n.body}</div>
                    <div className="notif-time">
                      {formatRelativeTime(n.created_at)}
                    </div>
                  </div>
                  {!n.is_read && <div className="notif-dot" />}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ══════════════════════════════
// FULL NOTIFICATIONS PAGE
// ══════════════════════════════
export function NotificationsPage() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState('all'); // all | unread

  const { data, isLoading } = useQuery({
    queryKey: ['admin-notifications'],
    queryFn: notifApi.list,
  });

  const notifications = (data?.data?.data || []).filter(n =>
    filter === 'all' ? true : !n.is_read
  );

  const markAllMutation = useMutation({
    mutationFn: notifApi.markAll,
    onSuccess: () => queryClient.invalidateQueries(['admin-notifications']),
  });

  const markOneMutation = useMutation({
    mutationFn: (id) => notifApi.markOne(id),
    onSuccess: () => queryClient.invalidateQueries(['admin-notifications']),
  });

  return (
    <div className="notif-page">
      <div className="admin-page-header">
        <div>
          <h1 className="admin-page-title">Notifications</h1>
          <p className="admin-page-sub">
            {notifications.filter(n => !n.is_read).length} unread
          </p>
        </div>
        <button
          className="btn-outline-gold"
          onClick={() => markAllMutation.mutate()}
          disabled={markAllMutation.isPending}
        >
          ✓ Mark all as read
        </button>
      </div>

      <div className="filter-tabs" style={{ marginBottom: '20px' }}>
        {['all', 'unread'].map(f => (
          <button
            key={f}
            className={`filter-tab ${filter === f ? 'active' : ''}`}
            onClick={() => setFilter(f)}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="loading-rows">{[1,2,3].map(i => <div key={i} className="skeleton-row" />)}</div>
      ) : (
        <div className="notif-page-list">
          {notifications.map(n => (
            <div
              key={n.id}
              className={`notif-page-item ${!n.is_read ? 'unread' : ''}`}
              onClick={() => !n.is_read && markOneMutation.mutate(n.id)}
            >
              <div className="notif-type-icon large">{getNotifIcon(n.type)}</div>
              <div className="notif-content">
                <div className="notif-title">{n.title}</div>
                <div className="notif-body">{n.body}</div>
                <div className="notif-time">{formatRelativeTime(n.created_at)}</div>
              </div>
              <div className="notif-item-right">
                {!n.is_read
                  ? <span className="notif-unread-label">Unread</span>
                  : <span className="notif-read-label">Read</span>}
                <span className="notif-type-badge">{formatType(n.type)}</span>
              </div>
            </div>
          ))}
          {notifications.length === 0 && (
            <div className="empty-state">
              <div className="empty-icon">🔕</div>
              <p>No {filter === 'unread' ? 'unread ' : ''}notifications</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Helpers ───
function getNotifIcon(type) {
  const icons = {
    new_pitch:               '💡',
    registration_milestone:  '🎉',
    new_registration:        '👤',
  };
  return icons[type] || '🔔';
}

function formatType(type) {
  return type?.replace(/_/g, ' ') || 'General';
}

function formatRelativeTime(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1)  return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24)  return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7)  return `${days}d ago`;
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}
