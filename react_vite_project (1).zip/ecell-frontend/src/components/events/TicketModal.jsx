import { useQuery } from '@tanstack/react-query';
import { eventsApi } from '../../api/services';

export default function TicketModal({ slug, onClose }) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['my-registration', slug],
    queryFn: () => eventsApi.myRegistration(slug),
    enabled: !!slug,
  });

  const reg = data?.data;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box ticket-modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>

        <div className="ticket-header">
          <div className="ticket-logo">🎟️</div>
          <h2>Your Ticket</h2>
          <p>Show this QR at the entrance</p>
        </div>

        {isLoading && (
          <div className="ticket-loading">
            <div className="spinner" />
            <p>Loading your ticket...</p>
          </div>
        )}

        {isError && (
          <div className="ticket-error">
            <p>Could not load ticket. Please try again.</p>
          </div>
        )}

        {reg && (
          <div className="ticket-body">
            {/* QR Code Image from backend */}
            <div className="qr-wrapper">
              {reg.qr_image_url ? (
                <img
                  src={reg.qr_image_url}
                  alt="Your QR ticket"
                  className="qr-image"
                />
              ) : (
                <div className="qr-placeholder">
                  <p>QR code is being generated.</p>
                  <p>Check your email!</p>
                </div>
              )}
              <div className="qr-scan-hint">Scan at entry</div>
            </div>

            {/* Registration details */}
            <div className="ticket-details">
              <div className="ticket-row">
                <span className="ticket-label">Event</span>
                <span className="ticket-value">{reg.event_title}</span>
              </div>
              <div className="ticket-row">
                <span className="ticket-label">Name</span>
                <span className="ticket-value">{reg.name}</span>
              </div>
              <div className="ticket-row">
                <span className="ticket-label">USN</span>
                <span className="ticket-value">{reg.usn}</span>
              </div>
              <div className="ticket-row">
                <span className="ticket-label">Department</span>
                <span className="ticket-value">{reg.department}</span>
              </div>
              <div className="ticket-row">
                <span className="ticket-label">Reg. ID</span>
                <span className="ticket-value ticket-id">#{reg.id}</span>
              </div>
              <div className="ticket-row">
                <span className="ticket-label">Status</span>
                <span className={`ticket-status ${reg.attended ? 'present' : 'pending'}`}>
                  {reg.attended ? '✓ Attended' : '⏳ Not yet attended'}
                </span>
              </div>
            </div>

            <div className="ticket-note">
              A copy has been sent to <strong>{reg.email}</strong>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
